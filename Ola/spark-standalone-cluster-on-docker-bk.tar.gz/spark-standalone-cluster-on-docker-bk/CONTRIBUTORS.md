# Contributors

Hi there, thanks for helping the project! We are doing our best to help the community to learn and practice
parallel computing in distributed environments through our projects. :sparkles:

- **André Perez** - [dekoperez](https://twitter.com/dekoperez) - andre.marcos.perez@gmail.com