---
name: Feature Request
about: Create a feature request to help us improve the project
title: '[FEATURE]'
labels: ''
assignees: 'andre-marcos-perez'

---

## Introduction

Hi there, thanks for helping the project! We are doing our best to help the community to learn and practice
parallel computing in distributed environments through our projects. :sparkles:

## Feature

Please fill the template below.

### Description

*Describe your feature request*

### Comments (optional)

*Add some comments, if any*