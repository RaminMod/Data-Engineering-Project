#!/bin/bash

export SPARK_HOME="/spark"
export PATH="${PATH}:$SPARK_HOME/bin"
export SPARK_NO_DAEMONIZE="true"
. "${SPARK_HOME}/sbin/load-spark-env.sh"

# Start Spark master
${SPARK_HOME}/sbin/start-master.sh

# Start Jupyter notebook
jupyter-notebook --ip=0.0.0.0 --no-browser --allow-root --NotebookApp.token=''
